export const environment = {
  production: true,
  apiUrl: 'http://localhost:4000',
  testUrl:"http://universitiesconnect.com/bongoswriters/api_1_0_0/Api",
  baseUrl : 'http://universitiesconnect.com/php/api',
  tokenurl :"http://universitiesconnect.com/bongoswriters/api_1_0_0/token/token"
};
